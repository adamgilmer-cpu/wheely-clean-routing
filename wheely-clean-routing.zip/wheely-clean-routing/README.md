# Wheely Clean — Smart Appointment Routing App

This app helps new patients find appointment times when your van is already in their neighbourhood.

---

## How It Works

1. Patient enters their address
2. App checks your upcoming NexHealth appointments and finds the closest ones geographically
3. App shows available slots before and after those nearby appointments
4. If nothing works, patient can try the next closest area (up to 3 times)
5. After 3 tries, they're sent to your regular booking page
6. Once they pick a time, they choose appointment type and enter their details

---

## Step 1 — Get Your NexHealth IDs

After deploying (Step 4), visit:

```
https://your-app-name.vercel.app/api/setup
```

This will show you a list of your locations, providers, and appointment types with their IDs.
Copy those IDs — you'll need them in Step 3.

---

## Step 2 — Get a Google Maps API Key

1. Go to https://console.cloud.google.com
2. Sign in with your Google account
3. Create a project called "Wheely Clean"
4. Search for "Geocoding API" and click Enable
5. Go to Credentials → Create Credentials → API Key
6. Copy the key
7. Click Edit on the key → API Restrictions → Restrict to "Geocoding API" → Save

---

## Step 3 — Add Your Environment Variables in Vercel

In Vercel, go to your project → Settings → Environment Variables and add:

| Variable | Value |
|---|---|
| NEXHEALTH_API_KEY | Your NexHealth API key |
| NEXHEALTH_SUBDOMAIN | wheelyclean |
| NEXHEALTH_LOCATION_ID | From /api/setup |
| NEXHEALTH_PROVIDER_ID | From /api/setup |
| GOOGLE_MAPS_API_KEY | From Google Cloud Console |

After adding variables, go to Deployments → click the three dots on your latest deployment → Redeploy.

---

## Step 4 — Deploy to Vercel

1. Go to https://vercel.com and sign in
2. Click "Add New Project"
3. Upload this folder (drag and drop the wheely-clean-routing folder)
4. Click Deploy
5. Your app will be live at a URL like https://wheely-clean-routing.vercel.app

---

## Step 5 — Find Your IDs

Visit https://your-app.vercel.app/api/setup
Copy the IDs into Vercel environment variables (Step 3)
Redeploy

---

## Connecting to Your Squarespace Site

Once the app is live on Vercel, you can link to it from your Squarespace site like any regular URL.

You can also point a subdomain like booking.wheelyclean.ca to it:
1. In Vercel → your project → Settings → Domains → Add Domain
2. Type: booking.wheelyclean.ca
3. Vercel will show you DNS settings to add in your domain registrar

---

## Need Help?

Contact your developer or ask Claude at claude.ai for help troubleshooting.
