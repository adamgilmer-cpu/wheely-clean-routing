// app/api/appointments/route.js
// Fetches upcoming appointments + patient addresses, then ranks by distance

import { nexhealthGet } from '@/lib/nexhealth'
import { geocodeAddress, distanceKm } from '@/lib/geocode'

export async function POST(req) {
  try {
    const { address } = await req.json()
    if (!address) return Response.json({ error: 'Address is required' }, { status: 400 })

    // Geocode the new patient's address
    let patientCoords
    try {
      patientCoords = await geocodeAddress(address)
    } catch {
      return Response.json({ error: 'Could not find that address. Please try entering it more specifically.' }, { status: 400 })
    }

    // Fetch appointments for the next 30 days
    const today = new Date()
    const in30 = new Date(today)
    in30.setDate(today.getDate() + 30)

    const startStr = today.toISOString().split('T')[0]
    const endStr = in30.toISOString().split('T')[0]

    const apptRes = await nexhealthGet('/appointments', {
      start: startStr,
      end: endStr,
      'include[]': 'patient'
    })

    const appointments = apptRes.data?.appointments || apptRes.data || []

    // For each appointment, get patient address and geocode it
    const enriched = await Promise.allSettled(
      appointments.map(async (appt) => {
        const patientId = appt.patient_id || appt.patient?.id
        if (!patientId) return null

        // Try to get address from included patient data first
        let patientAddress = appt.patient?.address
          || appt.patient?.bio?.address

        // If not included, fetch separately
        if (!patientAddress) {
          try {
            const patRes = await nexhealthGet(`/patients/${patientId}`)
            const pat = patRes.data?.patient || patRes.data
            patientAddress = pat?.address || pat?.bio?.address
          } catch {
            return null
          }
        }

        if (!patientAddress) return null

        // Build a searchable address string
        const addrString = typeof patientAddress === 'string'
          ? patientAddress
          : [patientAddress.street, patientAddress.city, patientAddress.state].filter(Boolean).join(', ')

        if (!addrString) return null

        let coords
        try {
          coords = await geocodeAddress(addrString)
        } catch {
          return null
        }

        const dist = distanceKm(patientCoords.lat, patientCoords.lng, coords.lat, coords.lng)

        return {
          id: appt.id,
          date: appt.start_time || appt.date,
          providerId: appt.provider_id,
          patientAddress: addrString,
          area: coords.formattedAddress,
          distKm: dist,
          lat: coords.lat,
          lng: coords.lng
        }
      })
    )

    const valid = enriched
      .filter(r => r.status === 'fulfilled' && r.value !== null)
      .map(r => r.value)
      .sort((a, b) => a.distKm - b.distKm)

    // Group by area (deduplicate same-day same-area appointments)
    const grouped = []
    const seen = new Set()
    for (const appt of valid) {
      const dateKey = new Date(appt.date).toDateString()
      const areaKey = `${Math.round(appt.lat * 100)},${Math.round(appt.lng * 100)}`
      const key = `${dateKey}-${areaKey}`
      if (!seen.has(key)) {
        seen.add(key)
        grouped.push(appt)
      }
    }

    return Response.json({
      patientCoords,
      appointments: grouped.slice(0, 10)
    })
  } catch (err) {
    console.error('Appointments API error:', err)
    return Response.json({ error: 'Something went wrong fetching appointments. Please try again.' }, { status: 500 })
  }
}
