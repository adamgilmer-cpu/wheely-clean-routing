// app/api/slots/route.js
// Fetches available appointment slots before and after a nearby existing appointment

import { nexhealthGet } from '@/lib/nexhealth'

export async function POST(req) {
  try {
    const { appointmentDate, providerId, appointmentTypeId } = await req.json()

    if (!appointmentDate) {
      return Response.json({ error: 'appointmentDate is required' }, { status: 400 })
    }

    const date = new Date(appointmentDate)
    const dateStr = date.toISOString().split('T')[0]

    // Also check day before and day after for flexibility
    const dayBefore = new Date(date)
    dayBefore.setDate(date.getDate() - 1)
    const dayAfter = new Date(date)
    dayAfter.setDate(date.getDate() + 1)

    const params = {
      start_date: dayBefore.toISOString().split('T')[0],
      end_date: dayAfter.toISOString().split('T')[0],
    }

    if (providerId) params.provider_id = providerId
    if (appointmentTypeId) params.appointment_type_id = appointmentTypeId

    const slotsRes = await nexhealthGet('/appointment_slots', params)
    const allSlots = slotsRes.data?.appointment_slots || slotsRes.data || []

    // Split into before/same-day/after relative to the existing appointment time
    const apptTime = date.getTime()

    const before = []
    const after = []

    for (const slot of allSlots) {
      const slotTime = new Date(slot.time || slot.start_time).getTime()
      const slotObj = {
        id: slot.id,
        time: slot.time || slot.start_time,
        providerId: slot.provider_id
      }
      if (slotTime < apptTime) {
        before.push(slotObj)
      } else {
        after.push(slotObj)
      }
    }

    // Return last 2 before slots and first 2 after slots
    return Response.json({
      before: before.slice(-2),
      after: after.slice(0, 2),
      date: dateStr
    })
  } catch (err) {
    console.error('Slots API error:', err)
    return Response.json({ error: 'Could not fetch available slots. Please try again.' }, { status: 500 })
  }
}
