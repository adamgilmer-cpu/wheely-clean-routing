// app/api/setup/route.js
// Visit /api/setup once after deploying to find your IDs
// Then paste them into your Vercel environment variables

import { nexhealthGet } from '@/lib/nexhealth'

export async function GET() {
  try {
    const [locationsRes, providersRes, apptTypesRes] = await Promise.all([
      nexhealthGet('/locations', { subdomain: process.env.NEXHEALTH_SUBDOMAIN }),
      nexhealthGet('/providers'),
      nexhealthGet('/appointment_types')
    ])

    const locations = locationsRes.data?.locations || locationsRes.data || []
    const providers = providersRes.data?.providers || providersRes.data || []
    const apptTypes = apptTypesRes.data?.appointment_types || apptTypesRes.data || []

    return Response.json({
      message: 'Copy these IDs into your Vercel environment variables',
      instructions: {
        NEXHEALTH_LOCATION_ID: 'Pick the ID of your Wheely Clean location below',
        NEXHEALTH_PROVIDER_ID: 'Pick your provider ID below',
        NEXHEALTH_APPOINTMENT_TYPE_IDS: 'Comma-separated list of appointment type IDs you want to offer'
      },
      locations: locations.map(l => ({ id: l.id, name: l.name, address: l.address })),
      providers: providers.map(p => ({ id: p.id, name: `${p.first_name} ${p.last_name}`, email: p.email })),
      appointmentTypes: apptTypes.map(t => ({ id: t.id, name: t.name, duration: t.duration }))
    })
  } catch (err) {
    return Response.json({ error: err.message }, { status: 500 })
  }
}
