'use client'

import { useState } from 'react'

const APPOINTMENT_TYPES = [
  { id: process.env.NEXT_PUBLIC_APPT_TYPE_CLEANING || '1', name: 'Dental Cleaning', duration: '60 min', desc: 'Full cleaning with our registered dental hygienist' },
  { id: process.env.NEXT_PUBLIC_APPT_TYPE_WHITENING || '2', name: 'Teeth Whitening', duration: '90 min', desc: 'Professional whitening treatment' },
  { id: process.env.NEXT_PUBLIC_APPT_TYPE_BOTH || '3', name: 'Cleaning + Whitening', duration: '120 min', desc: 'Cleaning followed by whitening in one visit' },
]

const MAX_NONE_CLICKS = 3

function formatDate(dateStr) {
  const d = new Date(dateStr)
  return d.toLocaleDateString('en-CA', { weekday: 'short', month: 'short', day: 'numeric' })
}

function formatTime(timeStr) {
  const d = new Date(timeStr)
  return d.toLocaleTimeString('en-CA', { hour: 'numeric', minute: '2-digit', hour12: true })
}

export default function BookingPage() {
  const [step, setStep] = useState('address') // address | results | apptType | details | confirm
  const [address, setAddress] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [appointments, setAppointments] = useState([])
  const [currentApptIndex, setCurrentApptIndex] = useState(0)
  const [currentSlots, setCurrentSlots] = useState(null)
  const [slotsLoading, setSlotsLoading] = useState(false)
  const [noneClicks, setNoneClicks] = useState(0)
  const [selectedSlot, setSelectedSlot] = useState(null)
  const [selectedApptType, setSelectedApptType] = useState(null)
  const [patientDetails, setPatientDetails] = useState({ name: '', email: '', phone: '' })
  const [submitted, setSubmitted] = useState(false)

  async function handleAddressSearch() {
    if (!address.trim()) {
      setError('Please enter your address.')
      return
    }
    setError('')
    setLoading(true)

    try {
      const res = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Something went wrong')
      if (!data.appointments?.length) {
        setError('No upcoming appointments found in your area. Please call us directly.')
        setLoading(false)
        return
      }
      setAppointments(data.appointments)
      setCurrentApptIndex(0)
      setNoneClicks(0)
      await loadSlots(data.appointments[0])
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  async function loadSlots(appt) {
    setSlotsLoading(true)
    setCurrentSlots(null)
    try {
      const res = await fetch('/api/slots', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appointmentDate: appt.date,
          providerId: appt.providerId
        })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setCurrentSlots(data)
      setStep('results')
    } catch (err) {
      setError(err.message)
    } finally {
      setSlotsLoading(false)
    }
  }

  async function handleNoneWork() {
    const newClicks = noneClicks + 1
    setNoneClicks(newClicks)

    if (newClicks >= MAX_NONE_CLICKS) {
      setStep('anyTime')
      return
    }

    const nextIndex = currentApptIndex + 1
    if (nextIndex >= appointments.length) {
      setStep('anyTime')
      return
    }

    setCurrentApptIndex(nextIndex)
    await loadSlots(appointments[nextIndex])
  }

  function handleSlotSelect(slot, type) {
    setSelectedSlot({ ...slot, slotType: type })
    setStep('apptType')
  }

  function handleApptTypeSelect(type) {
    setSelectedApptType(type)
    setStep('details')
  }

  function handleDetailsChange(e) {
    setPatientDetails(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  async function handleConfirm() {
    setLoading(true)
    // In production this would call NexHealth to book the appointment
    // For now we show a confirmation
    await new Promise(r => setTimeout(r, 1000))
    setSubmitted(true)
    setStep('done')
    setLoading(false)
  }

  const currentAppt = appointments[currentApptIndex]
  const hasMoreAreas = currentApptIndex + 1 < appointments.length

  return (
    <div style={styles.page}>
      <div style={styles.container}>

        {/* Header */}
        <div style={styles.header}>
          <div style={styles.logoIcon}>
            <svg width="18" height="18" viewBox="0 0 20 20" fill="none">
              <path d="M10 2C7 2 4 4.5 4 8c0 4.5 6 10 6 10s6-5.5 6-10c0-3.5-3-6-6-6z" fill="white" opacity="0.9"/>
              <circle cx="10" cy="8" r="2.5" fill="#1D9E75"/>
            </svg>
          </div>
          <div>
            <div style={styles.logoText}>Wheely Clean</div>
            <div style={styles.logoSub}>Mobile dental hygiene · Victoria, BC</div>
          </div>
        </div>

        {/* Step: Address */}
        {step === 'address' && (
          <div style={styles.card} className="fade-in">
            <div style={styles.cardTitle}>Find appointments near you</div>
            <div style={styles.cardSub}>Enter your address and we'll show you times when our van is already in your neighbourhood — no extra travel charge.</div>
            <label style={styles.label}>Your home address</label>
            <input
              style={styles.input}
              type="text"
              placeholder="e.g. 1234 Oak Bay Ave, Victoria"
              value={address}
              onChange={e => setAddress(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAddressSearch()}
            />
            {error && <div style={styles.errorBox}>{error}</div>}
            <button
              style={{ ...styles.btnPrimary, opacity: loading ? 0.7 : 1 }}
              onClick={handleAddressSearch}
              disabled={loading}
            >
              {loading ? 'Searching...' : 'Find available appointments near me'}
            </button>
          </div>
        )}

        {/* Loading slots */}
        {slotsLoading && (
          <div style={styles.spinner}>
            <div style={styles.spinnerRing} />
            Finding available times in your area...
          </div>
        )}

        {/* Step: Results */}
        {step === 'results' && currentAppt && currentSlots && (
          <div className="fade-in">
            <div style={styles.resultsHeader}>
              <span>Available near <strong>{currentAppt.area?.split(',')[0]}</strong></span>
              <span style={styles.distBadge}>{currentAppt.distKm.toFixed(1)} km from you</span>
            </div>

            {currentSlots.before.length === 0 && currentSlots.after.length === 0 && (
              <div style={styles.cardSub}>No open slots found near this area.</div>
            )}

            {currentSlots.before.map((slot, i) => (
              <div key={slot.id || i} style={styles.slotCard} onClick={() => handleSlotSelect(slot, 'before')}>
                <div>
                  <span style={{ ...styles.badge, background: '#E6F1FB', color: '#185FA5' }}>Before nearby appointment</span>
                  <div style={styles.slotDate}>{formatDate(slot.time)}</div>
                  <div style={styles.slotTime}>{formatTime(slot.time)}</div>
                </div>
                <div style={styles.slotRight}>
                  <div style={styles.slotDist}>{currentAppt.distKm.toFixed(1)} km</div>
                  <div style={styles.slotDistLabel}>from you</div>
                </div>
              </div>
            ))}

            {currentSlots.after.map((slot, i) => (
              <div key={slot.id || i} style={{ ...styles.slotCard, ...(i === 0 && currentSlots.before.length === 0 ? styles.slotCardTop : {}) }} onClick={() => handleSlotSelect(slot, 'after')}>
                <div>
                  <span style={{ ...styles.badge, background: '#E1F5EE', color: '#0F6E56' }}>After nearby appointment</span>
                  <div style={styles.slotDate}>{formatDate(slot.time)}</div>
                  <div style={styles.slotTime}>{formatTime(slot.time)}</div>
                </div>
                <div style={styles.slotRight}>
                  <div style={styles.slotDist}>{currentAppt.distKm.toFixed(1)} km</div>
                  <div style={styles.slotDistLabel}>from you</div>
                </div>
              </div>
            ))}

            <hr style={styles.divider} />

            <button style={styles.btnSecondary} onClick={handleNoneWork} disabled={slotsLoading}>
              {hasMoreAreas && noneClicks < MAX_NONE_CLICKS - 1
                ? `None of these work? Show next closest area →`
                : `None of these work? See all available times →`}
            </button>

            <span style={styles.resetLink} onClick={() => { setStep('address'); setAppointments([]); }}>
              Start over with a different address
            </span>
          </div>
        )}

        {/* Step: Any time (escape hatch after 3 none clicks) */}
        {step === 'anyTime' && (
          <div style={styles.card} className="fade-in">
            <div style={styles.cardTitle}>We couldn't find a perfect match</div>
            <div style={styles.cardSub}>No problem — you can still book any available time and we'll make it work. It just means a bit more driving for us!</div>
            <button style={styles.btnPrimary} onClick={() => window.open('https://wheelyclean.ca', '_blank')}>
              Book any available time →
            </button>
            <span style={styles.resetLink} onClick={() => { setStep('address'); setNoneClicks(0); }}>
              Try a different address
            </span>
          </div>
        )}

        {/* Step: Appointment type */}
        {step === 'apptType' && (
          <div className="fade-in">
            <div style={styles.resultsHeader}>
              <span>What type of appointment?</span>
            </div>
            <div style={styles.cardSub}>Selected time: <strong>{selectedSlot && formatDate(selectedSlot.time)} at {selectedSlot && formatTime(selectedSlot.time)}</strong></div>
            <div style={{ height: 12 }} />
            {APPOINTMENT_TYPES.map(type => (
              <div key={type.id} style={styles.slotCard} onClick={() => handleApptTypeSelect(type)}>
                <div>
                  <div style={styles.slotDate}>{type.name}</div>
                  <div style={styles.slotTime}>{type.desc}</div>
                </div>
                <div style={styles.slotRight}>
                  <div style={styles.slotDist}>{type.duration}</div>
                </div>
              </div>
            ))}
            <span style={styles.resetLink} onClick={() => setStep('results')}>← Back to time slots</span>
          </div>
        )}

        {/* Step: Patient details */}
        {step === 'details' && (
          <div style={styles.card} className="fade-in">
            <div style={styles.cardTitle}>Almost done!</div>
            <div style={styles.cardSub}>
              {selectedApptType?.name} · {formatDate(selectedSlot?.time)} at {formatTime(selectedSlot?.time)}
            </div>
            <div style={{ height: 16 }} />
            <label style={styles.label}>Full name</label>
            <input style={styles.input} type="text" name="name" placeholder="Jane Smith" value={patientDetails.name} onChange={handleDetailsChange} />
            <label style={styles.label}>Email address</label>
            <input style={styles.input} type="email" name="email" placeholder="jane@example.com" value={patientDetails.email} onChange={handleDetailsChange} />
            <label style={styles.label}>Phone number</label>
            <input style={styles.input} type="tel" name="phone" placeholder="250-555-0100" value={patientDetails.phone} onChange={handleDetailsChange} />
            {error && <div style={styles.errorBox}>{error}</div>}
            <button
              style={{ ...styles.btnPrimary, opacity: loading ? 0.7 : 1 }}
              onClick={handleConfirm}
              disabled={loading || !patientDetails.name || !patientDetails.email}
            >
              {loading ? 'Booking...' : 'Confirm appointment'}
            </button>
            <span style={styles.resetLink} onClick={() => setStep('apptType')}>← Back</span>
          </div>
        )}

        {/* Step: Done */}
        {step === 'done' && (
          <div style={{ ...styles.card, textAlign: 'center' }} className="fade-in">
            <div style={styles.successIcon}>✓</div>
            <div style={{ ...styles.cardTitle, marginBottom: 8 }}>You're booked!</div>
            <div style={styles.cardSub}>
              {selectedApptType?.name}<br />
              {formatDate(selectedSlot?.time)} at {formatTime(selectedSlot?.time)}<br /><br />
              We'll send a confirmation to <strong>{patientDetails.email}</strong>.<br />
              See you soon, {patientDetails.name.split(' ')[0]}!
            </div>
          </div>
        )}

      </div>
    </div>
  )
}

const styles = {
  page: {
    minHeight: '100vh',
    background: '#f5f5f3',
    display: 'flex',
    alignItems: 'flex-start',
    justifyContent: 'center',
    padding: '2rem 1rem',
  },
  container: {
    width: '100%',
    maxWidth: 520,
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
  },
  logoIcon: {
    width: 38,
    height: 38,
    background: '#1D9E75',
    borderRadius: 10,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    fontSize: 16,
    fontWeight: 600,
    color: '#1a1a1a',
  },
  logoSub: {
    fontSize: 12,
    color: '#888',
    marginTop: 1,
  },
  card: {
    background: 'white',
    borderRadius: 14,
    border: '0.5px solid #e5e5e5',
    padding: '1.5rem',
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: 600,
    marginBottom: 6,
    color: '#1a1a1a',
  },
  cardSub: {
    fontSize: 13,
    color: '#666',
    lineHeight: 1.6,
    marginBottom: 20,
  },
  label: {
    fontSize: 11,
    fontWeight: 600,
    color: '#888',
    textTransform: 'uppercase',
    letterSpacing: '0.05em',
    display: 'block',
    marginBottom: 6,
  },
  input: {
    width: '100%',
    padding: '10px 12px',
    fontSize: 14,
    border: '0.5px solid #ddd',
    borderRadius: 8,
    background: '#fafafa',
    color: '#1a1a1a',
    outline: 'none',
    marginBottom: 14,
    fontFamily: 'inherit',
  },
  btnPrimary: {
    width: '100%',
    padding: '12px',
    background: '#1D9E75',
    color: 'white',
    border: 'none',
    borderRadius: 8,
    fontSize: 14,
    fontWeight: 500,
    cursor: 'pointer',
    fontFamily: 'inherit',
  },
  btnSecondary: {
    width: '100%',
    padding: '11px',
    background: 'white',
    color: '#555',
    border: '0.5px solid #ddd',
    borderRadius: 8,
    fontSize: 13,
    fontWeight: 500,
    cursor: 'pointer',
    fontFamily: 'inherit',
    marginBottom: 10,
  },
  errorBox: {
    background: '#fff0f0',
    border: '0.5px solid #fcc',
    borderRadius: 8,
    padding: '10px 12px',
    fontSize: 13,
    color: '#c0392b',
    marginBottom: 12,
  },
  spinner: {
    textAlign: 'center',
    padding: '2rem',
    color: '#888',
    fontSize: 13,
  },
  spinnerRing: {
    width: 28,
    height: 28,
    border: '2.5px solid #eee',
    borderTopColor: '#1D9E75',
    borderRadius: '50%',
    animation: 'spin 0.8s linear infinite',
    margin: '0 auto 12px',
  },
  resultsHeader: {
    fontSize: 13,
    fontWeight: 500,
    color: '#555',
    marginBottom: 12,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  distBadge: {
    fontSize: 11,
    background: '#E1F5EE',
    color: '#0F6E56',
    padding: '3px 8px',
    borderRadius: 4,
    fontWeight: 500,
  },
  slotCard: {
    background: 'white',
    border: '0.5px solid #e5e5e5',
    borderRadius: 10,
    padding: '1rem 1.25rem',
    marginBottom: 8,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    cursor: 'pointer',
    transition: 'border-color 0.15s',
  },
  slotCardTop: {
    border: '1.5px solid #1D9E75',
  },
  badge: {
    fontSize: 10,
    fontWeight: 500,
    padding: '3px 8px',
    borderRadius: 4,
    marginBottom: 4,
    display: 'inline-block',
  },
  slotDate: {
    fontSize: 15,
    fontWeight: 500,
    color: '#1a1a1a',
  },
  slotTime: {
    fontSize: 13,
    color: '#888',
    marginTop: 2,
  },
  slotRight: {
    textAlign: 'right',
  },
  slotDist: {
    fontSize: 15,
    fontWeight: 500,
    color: '#1a1a1a',
  },
  slotDistLabel: {
    fontSize: 11,
    color: '#aaa',
  },
  divider: {
    border: 'none',
    borderTop: '0.5px solid #eee',
    margin: '14px 0',
  },
  resetLink: {
    display: 'block',
    textAlign: 'center',
    fontSize: 12,
    color: '#1D9E75',
    cursor: 'pointer',
    textDecoration: 'underline',
    marginTop: 10,
  },
  successIcon: {
    width: 48,
    height: 48,
    background: '#E1F5EE',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 22,
    color: '#1D9E75',
    margin: '0 auto 16px',
  },
}
