import './globals.css'

export const metadata = {
  title: 'Book an Appointment — Wheely Clean',
  description: 'Mobile dental hygiene in Victoria, BC. Find an appointment near you.',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
